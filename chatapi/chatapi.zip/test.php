<?php 
echo phpinfo();
//ok
?>