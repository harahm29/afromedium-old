<?php

namespace App\Http\Controllers\api\Base;

use App\Http\Controllers\Controller;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;

class BaseController extends Controller
{
    use ApiResponser;
}
